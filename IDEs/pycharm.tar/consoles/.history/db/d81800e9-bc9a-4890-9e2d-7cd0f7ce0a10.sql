select * from requests;
;-- -. . -..- - / . -. - .-. -.--
select * from tasks;
;-- -. . -..- - / . -. - .-. -.--
select * from images;