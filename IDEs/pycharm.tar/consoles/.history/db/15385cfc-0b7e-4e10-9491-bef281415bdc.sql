SELECT * FROM Saps WHERE sap_key = 'AutoSatelliteResetHours';
;-- -. . -..- - / . -. - .-. -.--
SELECT * FROM Saps;