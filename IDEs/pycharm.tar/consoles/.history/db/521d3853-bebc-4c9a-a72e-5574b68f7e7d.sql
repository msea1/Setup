SELECT * from metrics;
;-- -. . -..- - / . -. - .-. -.--
SELECT value from metrics;
;-- -. . -..- - / . -. - .-. -.--
SELECT value from datapoints;
;-- -. . -..- - / . -. - .-. -.--
SELECT * from tags;
;-- -. . -..- - / . -. - .-. -.--
SELECT * from datapoints;
;-- -. . -..- - / . -. - .-. -.--
SELECT * from datapoints where metric_key > 1;
;-- -. . -..- - / . -. - .-. -.--
SELECT
       timestamp,
       m.value,
       d.value
FROM datapoints d JOIN metrics m on d.metric_key = m.key
GROUP BY timestamp
ORDER BY timestamp ASC;
;-- -. . -..- - / . -. - .-. -.--
SELECT
       timestamp,
       m.value,
       d.value
FROM datapoints d JOIN metrics m on d.metric_key = m.key
ORDER BY timestamp ASC;
;-- -. . -..- - / . -. - .-. -.--
SELECT
       timestamp,
       m.value,
       d.value
FROM datapoints d JOIN metrics m on d.metric_key = m.key
GROUP BY metric_key
ORDER BY timestamp ASC;
;-- -. . -..- - / . -. - .-. -.--
SELECT
       timestamp,
       m.value,
       d.value
FROM datapoints d JOIN metrics m on d.metric_key = m.key
GROUP BY metric_key, timestamp
ORDER BY timestamp ASC;
;-- -. . -..- - / . -. - .-. -.--
select * from metrics;
;-- -. . -..- - / . -. - .-. -.--
SELECT tag_key, timestamp, value FROM datapoints WHERE metric_key = 'spacecraft.payload.camera.temp';
;-- -. . -..- - / . -. - .-. -.--
SELECT tag_key, timestamp, value FROM datapoints WHERE metric_key = 2;