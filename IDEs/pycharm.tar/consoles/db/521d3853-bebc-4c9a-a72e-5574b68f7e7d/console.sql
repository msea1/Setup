SELECT
       timestamp,
       m.value,
       d.value
FROM datapoints d JOIN metrics m on d.metric_key = m.key
GROUP BY metric_key, timestamp
ORDER BY timestamp ASC;


SELECT tag_key, timestamp, value FROM datapoints WHERE metric_key = 2;