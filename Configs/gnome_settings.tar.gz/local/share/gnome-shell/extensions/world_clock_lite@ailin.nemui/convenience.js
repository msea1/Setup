
const Gio = imports.gi.Gio;
const ExtensionUtils = imports.misc.extensionUtils;

function getClocksSettings() {
  let schema_id = 'org.gnome.clocks';
  if (Gio.Settings.list_schemas().indexOf(schema_id) == -1) {
    let extension = ExtensionUtils.getCurrentExtension();
    return new Gio.Settings({
      settings_schema: Gio.SettingsSchemaSource.new_from_directory(
	extension.dir.get_child('schemas').get_path(),
	Gio.SettingsSchemaSource.get_default(),
	false)
	.lookup(schema_id, false)
    });
  }
  else {
    return new Gio.Settings({ schema: schema_id });
  }
}

function getSettings() {
  let extension = ExtensionUtils.getCurrentExtension();
  return new Gio.Settings({
    settings_schema: Gio.SettingsSchemaSource.new_from_directory(
      extension.dir.get_child('schemas').get_path(),
      Gio.SettingsSchemaSource.get_default(),
      false)
      .lookup(extension.metadata['settings-schema'], false)
  });
}
